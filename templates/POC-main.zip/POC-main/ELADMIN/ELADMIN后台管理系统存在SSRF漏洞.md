# ELADMIN后台管理系统存在SSRF漏洞



## fofa

```javascript
"ELADMIN"
```

## poc

![image-20240809103414258](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202408091034318.png)



![image-20240809103420321](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202408091034373.png)