# Sharp多功能打印机未授权访问漏洞



## poc

```
/installed_emanual_list.html
```

![img](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202407261047600.png)