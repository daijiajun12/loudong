## Kuboard默认口令
漏洞描述：
Kuboard，是一款免费的 Kubernetes 图形化管理工具，Kuboard 力图帮助用户快速在 Kubernetes 上落地微服务。Kuboard存在默认口令可以通过默认口令登录Kuboard，管理Kubernetes。
admin/kuboard123
