## QQ客户端RCE漏洞
漏洞名称：QQ客户端RCE漏洞
漏洞类型：0day

产品官网链接：https://im.qq.com

影响范围：QQ Windows版9.7.13及以前版本

漏洞所在功能模块：文档传输下载模块

漏洞攻击效果：远程代码执行

## 漏洞复现
```
https://mp.weixin.qq.com/s/u4cmq3SQKzaFXVYj3Er8cg
https://mp.weixin.qq.com/s/ZjTPJHxGAz0qYaidbxOYmA
```
