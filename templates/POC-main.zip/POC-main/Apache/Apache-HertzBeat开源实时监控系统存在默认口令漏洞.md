# Apache-HertzBeat开源实时监控系统存在默认口令漏洞
HertzBeat(赫兹跳动) 是一个开源实时监控系统，无需Agent，性能集群，兼容Prometheus，自定义监控和状态页构建能力。HertzBeat 的强大自定义，多类型支持，高性能，易扩展，希望能帮助用户快速构建自有监控系统。HertzBeat(赫兹跳动) 开源实时监控系统存在默认口令漏洞。

## fofa

```javascript
app="HertzBeat-实时监控系统"
```

![](https://cdn.nlark.com/yuque/0/2024/png/29512878/1731984344118-f35cf51e-396b-4c72-958e-32a2ce31f18e.png)

## poc
```java
默认账号密码 admin/hertzbeat
```

![](https://cdn.nlark.com/yuque/0/2024/png/29512878/1731984356948-93102e68-6ce3-49cd-8bb6-44ceb8143325.png)

