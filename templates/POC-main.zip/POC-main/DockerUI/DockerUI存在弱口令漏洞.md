# DockerUI存在弱口令漏洞
DockerUI是一款开源的、强大的、轻量级的Docker管理工具。DockerUI覆盖了 docker cli 命令行 95% 以上的命令功能，通过可视化的界面，即使是不熟悉docker命令的用户也可以非常方便的进行Docker和Docker Swarm集群进行管理和维护。

## fofa
```javascript
"static/common/js/ui.js"
```

![](https://cdn.nlark.com/yuque/0/2024/png/1622799/1733724458922-5e7e71e5-70c8-412f-98a3-33fe85af2e92.png)

## poc
```java
ginghan/123456
```

![](https://cdn.nlark.com/yuque/0/2024/png/1622799/1733724482416-c8af339c-f4e7-424e-a4b8-48d7c01af37c.png)

